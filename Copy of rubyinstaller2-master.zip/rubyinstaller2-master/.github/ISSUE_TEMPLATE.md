This project is for Ruby version 2.4 and newer.
For Ruby versions < 2.4 please file an issue [here]( https://github.com/oneclick/rubyinstaller/issues/new ).

## What problems are you experiencing?


## Steps to reproduce


## What's the output from `ridk version`?

