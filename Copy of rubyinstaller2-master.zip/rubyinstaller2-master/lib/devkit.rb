require "ruby_installer/runtime"

RubyInstaller::Runtime.enable_msys_apps
